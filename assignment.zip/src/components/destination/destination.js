import React, { Component } from 'react'
import {connect} from 'react-redux';
import { removeFromList } from '../../redux/actions';

class Destination extends Component {
    render() {
        return (
            <div className="places__col places__col-destination">
                {this.props.places.map(currentItem => 
                    this.props.addedList.some(item => item.placeId === currentItem.id) && <div><h3>
                        {currentItem.name}
                    </h3>
                    
                    {this.props.addedList.filter(item => currentItem.id === item.placeId).map(item => (
                        <div className="listitem-delete" key={item.id} onClick={() => this.props.removeFromList(item)}>{item.name}</div>
                    ))}
                    </div>
                )}


                {this.props.addedList.length < 1 && <div>
                    No Items Added.
                    </div>}
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        places: state.listReducer.places,
        addedList: state.addedListReducer
    }
}

const mapDispatchToProps = dispatch => {
    return {
        removeFromList: item => dispatch(removeFromList(item))
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(Destination);

