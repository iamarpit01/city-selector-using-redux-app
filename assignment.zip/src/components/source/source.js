import React, { Component } from 'react';
import {connect} from 'react-redux';

import {addToList} from '../../redux/actions';

class Source extends Component {

    constructor(props){
        super(props);
        this.state = {
            checkedItems : []
        }
    }


    render() {
        return (
            <div className="places__col">
                { this.props.places.map(place => (
                    <div key={place.id}>
                        <h3>{place.name}</h3>
                        {this.props.subPlaces.map(subPlace => 
                             subPlace.placeId === place.id && <div>
                                {subPlace.placesList.map(finalPlace => (
                                    <div className="listitem" onClick={() => this.props.addToList(finalPlace)}>
                                        <div className="form-check">
                                            <input 
                                                value={finalPlace.value} 
                                                type="checkbox" 
                                                className="form-check-input"/>
                                            <label className="form-check-label" htmlFor={finalPlace.name}>{finalPlace.name}</label>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                ))}
            </div>
        )
    }
}

const mapStateToProps = (state) => ({
        places: state.listReducer.places,
        subPlaces: state.listReducer.subPlaces
    })

const mapDispatchToProps = dispatch => ({
        addToList: currentPlace => dispatch(addToList(currentPlace))
    })

export default connect(mapStateToProps, mapDispatchToProps)(Source)
