import {ADD_TO_LIST} from './constants';
import {REMOVE_FROM_LIST} from './constants';

export const addToList = currentItem => {
    return {
        type: ADD_TO_LIST,
        payload: currentItem
    }
}

export const removeFromList = currentItem => {
    return {
        type: REMOVE_FROM_LIST,
        payload: currentItem
    }
}